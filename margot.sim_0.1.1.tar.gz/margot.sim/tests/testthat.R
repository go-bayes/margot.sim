# This file is part of the standard testthat setup
library(testthat)
library(margot.sim)

test_check("margot.sim")