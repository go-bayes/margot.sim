
<!-- README.md is generated from README.Rmd. Please edit that file -->

# margot.sim

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
[![License:
MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![R-CMD-check](https://github.com/go-bayes/margot.sim/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/go-bayes/margot.sim/actions/workflows/R-CMD-check.yaml)
[![Codecov test
coverage](https://codecov.io/gh/go-bayes/margot.sim/branch/main/graph/badge.svg)](https://app.codecov.io/gh/go-bayes/margot.sim?branch=main)

<!-- [![GitHub stars](https://img.shields.io/github/stars/go-bayes/margot.sim?style=social)](https://github.com/go-bayes/margot.sim) -->

<!-- CRAN badges: will activate after CRAN release
[![CRAN status](https://www.r-pkg.org/badges/version/margot.sim)](https://CRAN.R-project.org/package=margot.sim)
[![Downloads](https://cranlogs.r-pkg.org/badges/margot.sim)](https://cran.r-project.org/package=margot.sim)
[![Total Downloads](https://cranlogs.r-pkg.org/badges/grand-total/margot.sim)](https://cran.r-project.org/package=margot.sim)
-->

<!-- badges: end -->

R package for simulating longitudinal data with realistic observational
shadows (measurement error, missingness, selection bias) and evaluating
causal inference methods via Monte Carlo simulation.

## Installation

You can install the development version of margot.sim from
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("go-bayes/margot.sim")
```

## What’s New in v0.1.2 (January 2025)

### Major Enhancements

- **Scenario Framework**: Bundle observational challenges into coherent
  scenarios for systematic sensitivity analysis
- **New Shadow Types**: Truncation, coarsening, and mode effects shadows
  for realistic data limitations
- **Enhanced Documentation**: 12 comprehensive vignettes covering all
  major features
- **Improved Architecture**: Dual data design preserves true and
  observed data throughout analysis

### Key New Features

``` r
# Create scenarios for sensitivity analysis
scenarios <- list(
  oracle = scenario_oracle(),  # Perfect measurement
  rct = scenario_rct_simple(),  # Typical RCT conditions
  observational = scenario_observational_simple(),  # Real-world messiness
  pessimistic = scenario_pessimistic()  # Worst-case scenario
)

# Compare effects across scenarios
comparison <- compare_scenarios(
  data = my_data,
  scenarios = scenarios,
  exposure = "treatment",
  outcome = "outcome"
)

# New shadow types
truncation <- create_truncation_shadow(
  variables = "income",
  upper = 200000  # Top-coding
)

coarsening <- create_coarsening_shadow(
  variables = "age",
  breaks = c(0, 30, 50, 70, 100),
  type = "heaping"  # Realistic rounding patterns
)
```

## Overview

margot.sim helps researchers understand how well their statistical
methods work when data are imperfect. The package provides:

1.  **Shadowing Framework** - Apply realistic observational distortions
2.  **Scenario Framework** - Bundle shadows into documented research
    contexts
3.  **Monte Carlo Framework** - Systematically evaluate estimator
    performance
4.  **Transport Weights** - Generalize from samples to populations
5.  **Flexible Distributions** - Model non-normal data

## Quick Start

``` r
library(margot.sim)

# 1. Generate data with a typical observational scenario
obs_scenario <- scenario_observational_simple()
sim_data <- margot_simulate(n = 1000, waves = 2)
observed_data <- apply_scenario(sim_data, obs_scenario)

# 2. Compare true vs observed effects
true_effects <- compute_causal_effects(
  observed_data$data_true,
  exposure = "t1_a",
  outcome = "t2_y"
)

biased_effects <- compute_causal_effects(
  observed_data$data_observed,
  exposure = "t1_a", 
  outcome = "t2_y"
)

# 3. Run sensitivity analysis across scenarios
scenarios <- scenario_collection_simple()
comparison <- compare_scenarios(
  sim_data,
  scenarios,
  exposure = "t1_a",
  outcome = "t2_y"
)

print(comparison)
plot(comparison)
```

## Core Features

### 1. Shadowing Framework

The package implements a comprehensive set of observational “shadows”
that distort true data:

**Measurement Error:**

``` r
# Classical error for continuous variables
me_shadow <- create_shadow(
  type = "measurement_error",
  params = list(
    variables = c("blood_pressure", "cholesterol"),
    error_type = "classical",
    sigma = 0.5
  )
)

# Misclassification for binary variables
misclass_shadow <- create_shadow(
  type = "measurement_error", 
  params = list(
    variables = "treatment",
    error_type = "misclassification",
    sensitivity = 0.85,  # 85% of treated correctly identified
    specificity = 0.90   # 90% of untreated correctly identified
  )
)

# Differential error (depends on other variables)
diff_shadow <- create_shadow(
  type = "measurement_error",
  params = list(
    variables = "self_reported_health",
    error_type = "differential",
    differential_var = "education",
    differential_fn = function(edu_values) {
      # More educated report health more accurately
      rnorm(length(edu_values), 0, 0.5 - 0.1 * edu_values)
    }
  )
)
```

**Data Limitations:**

``` r
# Truncation (values beyond limits not observed)
truncation <- create_truncation_shadow(
  variables = "biomarker",
  lower = 0,      # Detection limit
  upper = 1000,   # Equipment maximum
  type = "boundary"  # Values pile up at boundaries
)

# Coarsening (continuous data in categories)
coarsening <- create_coarsening_shadow(
  variables = "age",
  breaks = c(0, 18, 35, 50, 65, 100),
  type = "heaping",     # People round to 5s and 0s
  heaping_digits = c(0, 5),
  heaping_prob = 0.7
)

# Mode effects (measurement varies by collection method)
mode_effect <- create_mode_effects_shadow(
  variables = c("depression_score", "anxiety_score"),
  mode_var = "survey_mode",  # phone/web/in-person
  effects = list(
    phone = function(x) x + rnorm(length(x), -0.5, 0.2),
    web = function(x) x,
    in_person = function(x) x + rnorm(length(x), 0.3, 0.1)
  )
)
```

**Missing Data:**

``` r
# Item-level missingness with different mechanisms
miss_shadow <- create_item_missingness_shadow(
  variables = c("income", "health_status"),
  missing_mechanism = "MAR",  # or "MCAR", "MNAR"
  missing_rate = 0.2,
  dependent_vars = c("age", "education")
)
```

**Selection Bias:**

``` r
# Positivity violations
pos_shadow <- create_positivity_shadow(
  exposure_var = "treatment",
  filter_fn = function(data) {
    # Treatment only available to low-risk patients
    data$risk_score <= 0.7
  }
)
```

### 2. Scenario Framework

Scenarios bundle shadows with documentation for systematic sensitivity
analysis:

``` r
# Create a COVID vaccine effectiveness scenario
covid_scenario <- create_scenario(
  name = "COVID Vaccine Study",
  shadows = list(
    # Vaccination status misclassified
    vaccine_misclass = create_shadow(
      type = "measurement_error",
      params = list(
        variables = "vaccinated",
        error_type = "misclassification",
        sensitivity = 0.95,
        specificity = 0.98
      )
    ),
    # Differential testing by vaccination status
    testing_bias = create_shadow(
      type = "measurement_error",
      params = list(
        variables = "covid_positive",
        error_type = "differential",
        differential_var = "vaccinated",
        differential_fn = function(vax) {
          # Vaccinated more likely to test
          ifelse(vax == 1, 
                 rnorm(length(vax), 0, 0.1),
                 rnorm(length(vax), 0, 0.3))
        }
      )
    )
  ),
  description = "COVID-19 vaccine effectiveness with real-world biases",
  justification = "Testing behavior and record-keeping vary by vaccination status",
  references = c("Lipsitch M, et al. NEJM 2021", "Hernan MA, et al. Ann Intern Med 2021")
)

# Use pre-built scenario library
scenarios <- scenario_collection_simple()
# Includes: oracle, rct, observational, pessimistic
```

### 3. Monte Carlo Framework

Systematically evaluate estimator performance:

``` r
# Define estimator
ipw_estimator <- function(data) {
  # Propensity score model
  ps_model <- glm(treatment ~ age + gender + baseline_health, 
                  data = data, family = binomial)
  ps <- predict(ps_model, type = "response")
  
  # IPW weights
  weights <- ifelse(data$treatment == 1, 1/ps, 1/(1-ps))
  
  # Outcome model
  fit <- lm(outcome ~ treatment, weights = weights, data = data)
  
  list(
    estimate = coef(fit)["treatment"],
    se = sqrt(diag(vcov(fit)))["treatment"],
    converged = TRUE
  )
}

# Run Monte Carlo evaluation
mc_results <- margot_monte_carlo(
  n_reps = 1000,
  n_per_rep = 500,
  dgp_params = list(
    waves = 2,
    params = list(a_y_coef = 0.5)  # True effect
  ),
  shadows = list(misclass_shadow, miss_shadow),
  estimator_fn = ipw_estimator,
  truth_fn = function(data) 0.5,
  parallel = TRUE,
  n_cores = 4
)

# Automatic performance metrics
print(mc_results)
# - Bias: -0.12 (24% relative bias)
# - RMSE: 0.18
# - Coverage: 0.87 (nominal 0.95)
# - Power: 0.73
```

### 4. Transport Weights

Generalize from study samples to target populations:

``` r
# When your sample doesn't match your target population
transport_analysis <- margot_transport_analysis(
  sample_data = trial_data,
  population_data = registry_data,
  transport_vars = c("age", "comorbidity", "ses"),
  exposure = "treatment", 
  outcome = "mortality",
  shadows = list(
    # Registry data has measurement error
    create_shadow(
      type = "measurement_error",
      params = list(
        variables = "comorbidity",
        error_type = "misclassification",
        sensitivity = 0.85,
        specificity = 0.95
      )
    )
  )
)

print(transport_analysis$comparison)
# Sample ATE: 0.15 (trial participants)
# Population ATE: 0.08 (real-world patients)
# Transport bias: -0.07
```

## Documentation

Comprehensive vignettes cover all major features:

``` r
# Core functionality
vignette("basic-simulation")           # Getting started
vignette("applying-shadows")           # Shadow framework
vignette("scenario-sensitivity")       # NEW: Scenario-based analysis
vignette("monte-carlo-simple")         # Evaluating estimators

# Advanced topics
vignette("truncation-coarsening")      # NEW: Data limitations
vignette("misclassification-bias")     # Binary variable errors
vignette("shift-interventions")        # Modified treatment policies
vignette("transport-weights-shadows")  # Generalizing to populations

# Practical applications
vignette("heterogeneous-effects")      # Effect modification
vignette("censoring-effect-mod")       # Dropout and effect moderation
vignette("practical-workflow")         # Complete analysis workflow
```

## Future Directions

### Near-term (Q1-Q2 2025)

- **Causal method integration**: Direct support for `lmtp`, `grf`, and
  TMLE packages
- **Enhanced HTE framework**: Systematic heterogeneous treatment effect
  discovery
- **Diagnostic visualizations**: Balance plots, positivity checks,
  shadow validation
- **Performance optimizations**: Faster simulation for large-scale
  studies

### Medium-term (2025)

- **Interactive tools**: Shiny apps for exploring shadow impacts
- **Batch estimation**: Simultaneous evaluation of multiple estimators
- **Cross-package validation**: Compare results across causal inference
  ecosystems
- **Educational platform**: Interactive tutorials and case studies

### Long-term Vision

- **Comprehensive bias catalog**: Library of validated shadow parameters
  from literature
- **Automated sensitivity analysis**: Smart defaults based on study
  design
- **Integration hub**: Bridge between simulation and applied causal
  inference
- **Community repository**: User-contributed scenarios and shadows

## Why margot.sim?

Real studies rarely provide clean data. Instead, researchers face: -
Missing responses when participants skip questions or drop out -
Measurement errors from imperfect instruments or self-reports  
- Selection biases when treatment assignment isn’t random

Traditional simulations often ignore these challenges. margot.sim:

1.  **Mirrors reality** - Generates clean data then adds realistic
    distortions
2.  **Stress-tests methods** - Evaluates if your approach works when
    assumptions fail
3.  **Maintains truth** - Always knows ground truth for principled
    evaluation
4.  **Supports any estimator** - Flexible framework works with any
    statistical method
5.  **Builds confidence** - Demonstrates robustness before costly field
    studies

The framework’s power comes from maintaining **a clean separation
between true data-generating processes and observed data**, enabling
principled evaluation of statistical methods under realistic conditions.

## Contributing

We welcome contributions! Please:

1.  Fork the repository
2.  Create a feature branch (`git checkout -b feature/amazing-feature`)
3.  Add tests for new functionality
4.  Ensure all tests pass (`devtools::test()`)
5.  Submit a pull request

Priority areas for contribution: - Additional shadow types for
domain-specific biases - Pre-built scenarios for different research
fields - Integration with causal inference packages - Performance
optimizations

## Citation

If you use margot.sim in your research, please cite:

``` r
citation("margot.sim")
```

## License

MIT License - see [LICENSE.md](LICENSE.md) for details

## Acknowledgments

The shadow metaphor draws inspiration from Plato’s Allegory of the Cave,
reminding us that observed data are often distorted reflections of
underlying truths.

## References

``` r
# TBA
```
